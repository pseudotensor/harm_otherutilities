#!/bin/bash
#
scp -p *.sh *.par *.tcl makelog.c jmckinne@ki-rh39:/u/ki/jmckinne/nfsslac/orange.runs/blandford3d_new/grmhd32328/

scp -p *.sh *.par *.tcl makelog.c jmckinne@ki-rh39:/u/ki/jmckinne/nfsslac/lonestar.runs/runlocaldipole3dfiducial/
#
# on space where run (e.g. if doing lustre):
#  ln -s /u/ki/jmckinne/nfsslac/orange.runs/blandford3d_new/grmhd32328/* . 
#
#  ln -s /u/ki/jmckinne/nfsslac/lonestar.runs/runlocaldipole3dfiducial/* . 
#

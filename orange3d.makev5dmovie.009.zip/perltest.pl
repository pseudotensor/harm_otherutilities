#!/usr/bin/perl
use Math::Trig; #USE THIS MODULE

#print "content-type: text/html \n\n"; #HTTP HEADER
$real = 27;
$float = 3.14159;
$integer = -4;
$exponent = 10e12;
print tan($real);     #TANGENT FUNCTION
print "<br />";
print sin($float);    #SINE FUNCTION
print "<br />";
print acos($integer); #COSINE FUNCTION

#!/bin/bash

infile=$1
outfile=$2
nx=$3
ny=$4

# check if file already exists
if [ -s $outfile ]
then
    echo "file $outfile already exists, convert file or continue to next file"
    #continue
else
    echo "doing $infile -> $outfile"
    if [ -s $infile.left.ppm ] &&
	[ -s $infile.right.ppm ]
    then
	result=`montage +frame -bordercolor black -background black -borderwidth 0x0 -adjoin -geometry ${nx}x${ny}+0+0 -depth 8 -colors 256 $infile.left.ppm $infile.right.ppm $outfile 2>&1 | wc -w`
	if [ $result -ne 0 ]
	then
	    echo "Problem with montage of $infile.left.ppm $infile.right.ppm $outfile"
	    echo "Removing output file to report that failed and probably need to remake original files"
	    rm -rf $outfile
	fi
	# leave original .left and .right files

	# montage does not always obey -depth 8, so force with convert
	convert -colorspace RGB -colors 256 -depth 8 $outfile $outfile.tmp.ppm
	mv $outfile.tmp.ppm $outfile
    else
	echo "Error: No such files $infile.left.ppm $infile.right.ppm"
    fi
fi



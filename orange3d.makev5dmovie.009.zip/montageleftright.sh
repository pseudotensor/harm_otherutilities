#!/bin/bash

# sh montageleftright.sh 0 1499 "ifieldline" "v5dppmrefine/" "montdir/" 1920 1280

# check if any missing images
start=$1
finish=$2
nameprefix=$3
mydir=$4
montagedir=$5
nx=$6
ny=$7


for i in `seq $start $finish` ; do
    #
    mynum=$(printf "%04d" $i)

    infile=$(printf "%s%s%s.ppm" $mydir $nameprefix $mynum)
    outfile=$(printf "%s%s%s.ppm" $montagedir $nameprefix $mynum)

    echo $mynum $infile $outfile

    sh montageleftright.one.sh $infile $outfile $nx $ny

done


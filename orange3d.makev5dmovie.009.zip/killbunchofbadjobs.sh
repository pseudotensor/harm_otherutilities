#!/bin/bash
# to kill a bunch of these jobs:
#
jobprefix="viz"
bjobs | grep $jobprefix | awk '{print $1}' > badjobs.txt  
for fil in `cat badjobs.txt`; do echo $fil ; bkill $fil ; done





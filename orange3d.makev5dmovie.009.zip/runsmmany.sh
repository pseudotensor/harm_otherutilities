
#mydir=`basename $1`
jobname=$1
mydir=$2
start=$3
finish=$4
animskip=$5
remotexserver=$6
displaynum=$7
numcores=$8
do3dwall=$9
setresnx=${10}
setresny=${11}
# below are extra compared to runsmone.sh
truenumprocs=${12}
framefile=${13}


echo "Starting job" > $framefile.jobresult.txt

# sub loop over core frames
for j in `seq 1 $truenumprocs`
do
    # get one of frame numbers
    aframe=`cat $framefile | head -$j | tail -1`
    
    # now during a bsub job, submit each core's job
    # put into background so can do next job
    ./runsmone.sh $jobname $mydir $aframe $aframe 1 $remotexserver $displaynum $numcores $do3dwall $setresnx $setresny &
done

# wait for job control
sleep 2

while [ 1 -eq 1 ]
do
    # show only running jobs (done jobs hang around)
    result=`jobs -r | wc -w`
    resulttext=`jobs -r`
    echo "$resulttext" > $framefile.jobresult.txt
    if [ $result -eq 0 ]
    then
	break
    fi
    sleep 1
done

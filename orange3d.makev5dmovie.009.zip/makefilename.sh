echo "set outputfilename" \"$1\" > ${12}
#
echo "set ixmin [expr $2]" >> ${12}
echo "set ixmax [expr $3]" >> ${12}
#
echo "set iymin [expr $4]" >> ${12}
echo "set iymax [expr $5]" >> ${12}
#
echo "set izmin [expr $6]" >> ${12}
echo "set izmax [expr $7]" >> ${12}
#
#
echo "set bhspin [expr $8]" >> ${12}
echo "set startsimtime [expr $9]" >> ${12}
echo "set simtime [expr ${10}]" >> ${12}
#
echo "set dostereo [expr ${11}]" >> ${12}



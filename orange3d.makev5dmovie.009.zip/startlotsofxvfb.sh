#!/bin/bash
#

# sh startlotsofxvfb.sh

# each X server can only handle ~60 connections and each vis5d needs 3 connections, so for simplicity just start as many connections as files to process

# well, Xvfb eats lots of memory and doesn't give it back up

#
truestart=2
truefinish=6


for i in `seq $truestart $truefinish` ; do
    (Xvfb -ac :$i -screen 0 1024x768x24 &)
done



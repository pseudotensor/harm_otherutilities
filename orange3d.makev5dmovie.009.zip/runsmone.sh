# this script runs a single job on Orange to do a single fieldline file (bin2txt, iinterp, v5d, convert)

# to run this on Orange do:
# bsub -n 1 -R span[ptile=1] -q kipac-ibq -J viz1 -a openmpi ./runsmone.sh /u/ki/jmckinne/nfsslac/orange.runs/blandford3d_new/grmhd32328/ 0 0 1

# args to this script are: start finish skip

#
#
#
#mydir=`basename $1`
jobname=$1
mydir=$2
start=$3
finish=$4
animskip=$5
remotexserver=$6
displaynum=$7
numcores=$8
do3dwall=$9
setresnx=${10}
setresny=${11}

#
#

# see if existing display
echo "DISPLAY: $DISPLAY"
# below causes vis5d to fail.  Was used to avoid window opening for sm
# SM seems ok without sm if avoid x11 call, but vis5d+ needs X display since renders to frame buffer
# export DISPLAY=
#
#
# watch out! -- needs spaces before and after brackets
if [ $remotexserver -eq 1 ]
    # remote frame buffer
    then
    export DISPLAY=ki-rh42.slac.stanford.edu:$displaynum
    echo "Using RemoteDisplay: $DISPLAY"
fi

if [ $remotexserver -eq 0 ]
    then
    # then running Xvfb on local host
    #
    # testing for lock file intially not safe since delay could lead to another process also grabbing.  So just iterate through core numbers trying to get display and check for lock afterwards and break when got lock

    truedisplaynum=-1
    # Loop over possible cores
    for jj in `seq $displaynum $(($displaynum+$numcores-1))`
      do
      # wait a bit before retries
      sleep 2
      # Attempt to start Xvfb
      # apparently using back ticks and parentheses blocks despite &'s, so pipe to unique file instead
      echo "Xvfb resolution: ${setresnx}x${setresny}x24"
      # Note that Xvfb checks lock file and still starts as long as no such job name as shown in the lock file -- so good behavior
      (Xvfb -noreset -to 100000 -ac :$jj -screen 0 ${setresnx}x${setresny}x24  2>&1 &) 2>&1 > Xvfb.$jj.$jobname.f$start.$end
      cat Xvfb.$jj.$jobname.f$start.$end
      result2=`cat Xvfb.$jj.$jobname.f$start.$end | grep "already active" | wc -w`
      rm -rf Xvfb.$jj.$jobname.f$start.$end
      #echo $jj $result2
      # Check if Xvfb started correctly (i.e. no "already" AND "active" in output
      if [ $result2 -eq 0 ]
	  then
	  truedisplaynum=$jj
	  echo "Got Xvfb server $truedisplaynum for job $jobname $start $end"
	  break
      fi
    done

    if [ $truedisplaynum -eq -1 ]
	then
	echo "No Xvfb run"
    else
        #export DISPLAY=$HOSTNAME:$displaynum
        # below safer in general
	export DISPLAY=127.0.0.1:$truedisplaynum
	echo "Using LocalDisplay: $DISPLAY"
    fi
    # assume Xvfb gets started soon enough that vis5d (called later in jsm script currently) doesn't time-out trying to connect

fi


#
#
#
###################
# begin SM scripting
#
sleep 3
# check that Xvfb is really running
jobtocheck=`cat /tmp/.X$truedisplaynum-lock`
#
#ps -auxwf
result=`ps -auxwf | grep $jobtocheck | grep "Xvfb" | wc -w`
if [ $result -eq 0 ]
    then
    echo "No Xvfb really running!!!!"
    echo "WHAT TO DO"
    exit 1
fi

#
cd $mydir

# for lapack support for ~/sm/iinterp
source /u/ki/jmckinne/intel/mkl/10.0.5.025/tools/environment/mklvarsem64t.sh

echo "jsm with gofield1: $start $finish $animskip $do3dwall $setresnx $setresny"
jsm -f .smnox jre blandford.m gofield1 $start $finish $animskip $do3dwall $setresnx $setresny

#
###################
# wait a bit to let processes complete

sleep 2
#
#
#################
# clean-up the background Xvfb job(s?)
# no need to remove lock since any new Xvfb call will run even if lock as long as jobid inside lock is not running
# For multi-cores can't just kill all Xvfb jobs.  Specify to one job: $truedisplaynum
if [ $remotexserver -eq 0 ]
then
    
    ##################
    # old all-death way:
    #result=`ps -auxwf | grep Xvfb | awk '{print $1}'`
    #for fil in $result ; do
    #	echo "Killing Xvfb job# $fil"
    #	kill -s 9 $fil
    #	# clean-up lock file in case matters on some systems or some cases
    #	rm -rf /tmp/.X${displaynum}-lock
    #done

    #############
    # new way, just kill this job's program using $truedisplaynum from above
    jobtokill=`cat /tmp/.X$truedisplaynum-lock`
    # soft kill so job can finish properly
    kill $jobtokill
    # don't remove lock now since another process might start right after and start Xvfb

fi


##########
# done



# this script starts a set of jobs on orange
# base script is runsmone.sh

# to operate on lustre:
# 1) run copyorange.sh from orange3d directory
# 
# on orange:
# 2) cd /lustre/ki/orange/jmckinne/
# 3) (e.g.)
#
#  mkdir lustre_grmhd32328
#  cd lustre_grmhd32328
#  ln -s /u/ki/jmckinne/nfsslac/orange.runs/blandford3d_new/grmhd32328/* . 
#
# 4) Choose "mydir" below, and other parameters if required
#
# 5) Modify ~/sm/blandford.m as required (e.g. FIDUCIAL, DOINTERPSTAGE, etc.)
#
# 6) run as usual but inside the lustre dir
#
# sh runsmall.sh # see also 3dmovie.setup.tcl at top for instructions

# whether doing image or field type
# 0 = image type input 1 = data/fieldline output ppm 2 = just ensure v5d file created
DOFIELDTYPE=1

# whether to use listfix.txt for list of images to process
# otherwise use ordered list from truestart to truefinish
USELISTFIX=1

# whether to use listfix if first normal attempt didn't do all frames
USELISTFIXIFFAIL=1
# max number of repeat trials
MAXTRIALS=1000000

# total number of cores to use on queue for RUN + PEND jobs
TOTALCORESTOUSE=64

# seconds to delay when trying to repeat same job submission
SUBMITSECDELAY=15
MAXCOUNTDELAYCHECK=$(($SUBMITSECDELAY * 2 + 5))

# whether doing 3D wall or not (do3dwall==1 means rendering left+right frames for 3D wall, while do3dwall==0 means rendering 3D but making 1 eye)
do3dwall=0

# for non-3D wall
if [ $do3dwall -eq 0 ]
then
    # projectors usually have no better than this resolution
    setresnx=1024
    setresny=768
    jobprefix="viz"
fi
# for 3D wall
if [ $do3dwall -eq 1 ]
then
    setresnx=1920
    setresny=1280
    jobprefix="wall"
fi


# directories (must be consistent with blandford.m)
v5dppmrefinedir="./v5dppmrefine/"
v5ddir="./v5d/"






MYTRUE=1 # don't change
# use remotexserver=1 and numxservers (e.g.) 5 if started 5 Xvfb's on remote server
# use remotexserver=0 and numxservers 1 with numcores specified if to start Xvfb on compute node's core
################################3
# large range -- original choice
if [ 1 -eq $MYTRUE ]
    then
    #truestart=1000
    #truefinish=1000
    truestart=1000
    truefinish=1000
    #truefinish=1499 # can make 0 for testing, otherwise make last fieldline dump number
    #truestart=1230
    #truefinish=1230
    remotexserver=0
    numxservers=1
    numcores=4
    startxnum=2
fi


################################3
# refined range with local Xvfb
if [ 0 -eq $MYTRUE ]
    then
    truestart=1111
    truefinish=1499
    remotexserver=0
    numxservers=1
    numcores=4
    startxnum=2
fi

########################
# Choose directory to work in
###############
# LUSTRE new simulation
mydir=/lustre/ki/orange/jmckinne/lustre_runlocaldipole3dfiducial/
###############
# LUSTRE
#mydir=/lustre/ki/orange/jmckinne/lustre_grmhd32328/
###############
# NFS:
#mydir=/u/ki/jmckinne/nfsslac/orange.runs/blandford3d_new/grmhd32328/



#############################################
#
#
# END USER-DEFINED PARAMETERS
#
#
#############################################


###########################
#
# Loop over job creation
#
# Loop over attempts to finish all images
totalresult=1
timetofix=0
trialcount=1
firsttimeever=1
while [ $totalresult -ne 0 ]
  do

##############
# setup list
  if [ $USELISTFIXIFFAIL -eq 1 ] &&
      [ $timetofix -eq 1 ] ||
      [ $USELISTFIXIFFAIL -eq 0 ] &&
      [ $USELISTFIX -eq 1 ]
      then
      cp -a listfix.txt truelist.txt
  else
      if [ $truestart -gt $truefinish ]
	  then
	  echo "truestart=$truestart greater than truefinish=$truefinish"
	  exit 0
      fi

      seq $truestart $truefinish > truelist.txt

  fi


  ###################
  # Initialize seconds since submission array
  # 
  if [ $firsttimeever -eq 1 ]
  then
      firsttimeever=0
      # initialize last-submission seconds
      mysec=`date +%s`
      for i in `cat truelist.txt`
      do
	  secarray[$i]=$mysec
      done
  fi


  ####################################
  # real loop over frames
  #
  for i in `cat truelist.txt`
    do

    # name of job we want to start -- something unique
    jobname=$jobprefix$i



    ############
    # delay after last attempted same-job submission
    countdelaycheck=0
    while [ 1 -eq 1 ]
    do
        # get "Julian" seconds of submitted job
	mysec=`date +%s`
        # get seconds between last and this submission for this job
	diffsubmit=$(( $mysec - ${secarray[$i]} ))

	if [ $diffsubmit -gt $SUBMITSECDELAY ]
	    then
	    break
	fi

        # give the system a break
	# need to let bjob give correct result
        # only need this sleep if know repeating jobs -- bad for submitting lots of jobs at first
        # Somehow need to choose delay based upon last time of actually submitted job! (need 7 second delay in that case)
        #sleep 7
	sleep 1
	echo "x"
        #
	countdelaycheck=$(( $countdelaycheck + 1 ))
	if [ $countdelaycheck -gt $MAXCOUNTDELAYCHECK ]
	    then
	    echo "Problem with delay check: $countdelaycheck $MAXCOUNTDELAYCHECK"
	    #
	fi
    done




    #######################################
    # Wait to start the job until total number of cores drops to below limit set
    totaljobs=$(($TOTALCORESTOUSE+1))
    while [ $totaljobs -ge $TOTALCORESTOUSE ]
      do
	# this always done at least once, so can use result below
	pendjobs=`bjobs 2>&1 | grep $jobprefix | grep jmckinn | grep PEND | wc -l`
	runjobs=`bjobs 2>&1 | grep $jobprefix | grep jmckinn | grep RUN | wc -l`
	totaljobs=$(($pendjobs+$runjobs))

	if [ $totaljobs -ge $TOTALCORESTOUSE ]
	then
	    echo "Core Limit Reached: PEND=$pendjobs RUN=$runjobs TOTAL=$totaljobs ... waiting ..."
	    sleep 2
	fi
    done




    #######################################
    # check if cluster has job already in queue system that is same job trying to start
    alreadyresult=1
    #while [ -n $alreadyresult ]
    alreadyresult=`bjobs 2>&1 | grep $jobname | wc -w`
    if [ $alreadyresult -ne 0 ]
	then
	echo "Already doing job $jobname -- waiting to finish, skipping"
	#sleep 1
	continue
    fi


    ###########################################
    # Check if final file already generated, so skip

    # GODMARK: Should also check file size somehow since found some files non-zero but not correct size so some type of corruption from vis5d+
    # well, actually, if montage is done during each core's run and we check only for final output, then check there if montage failed and good enough
    mynum=$(printf "%04d" $i)
    # below for fieldline dumps
    if [ $DOFIELDTYPE -eq 1 ]
    then
	if [ $do3dwall -eq 0 ]
	then
	    myfile=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	fi
	if [ $do3dwall -eq 1 ]
	then
	    #myfile1=$(printf "%s/ifieldline%s.ppm.left.ppm" $v5dppmrefinedir $mynum)
	    #myfile2=$(printf "%s/ifieldline%s.ppm.right.ppm" $v5dppmrefinedir $mynum)
            # now that montage is done by each normal rendering, just check for final file
	    myfile1=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	    myfile2=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	fi
    elif [ $DOFIELDTYPE -eq 2 ]
    then
	if [ $do3dwall -eq 0 ]
	then
	    myfile=$(printf "%s/ifieldline%s.v5d" $v5ddir $mynum)
	fi
	if [ $do3dwall -eq 1 ]
	then
	    # no diff
	    myfile1=$(printf "%s/ifieldline%s.v5d" $v5ddir $mynum)
	    myfile2=$(printf "%s/ifieldline%s.v5d" $v5ddir $mynum)
	fi
    else
        # below for image dumps
	if [ $do3dwall -eq 0 ]
	then
	    myfile=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	fi
	
	if [ $do3dwall -eq 1 ]
	then
	    #myfile1=$(printf "%s/iim0p0s0l%s.ppm.left.ppm" $v5dppmrefinedir $mynum)
	    #myfile2=$(printf "%s/iim0p0s0l%s.ppm.right.ppm" $v5dppmrefinedir $mynum)
	    myfile1=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	    myfile2=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	fi
    fi


    # check existence of file(s):
    if [ $do3dwall -eq 0 ]
	then

	echo "tested file: $myfile"

	if [ -s $myfile ]
        then
            echo "file $myfile already exists, continuing to next file..."
	    continue
	fi
    else
	if [ -s $myfile1 ] &&
	    [ -s $myfile2 ]
	then
            echo "file $myfile1 AND $myfile2 already exist, continuing to next file..."
	    continue
	fi
    fi





    
    ################## avoid this method -- use new method that allows more pending jobs as at top of the loop, so just skip this
    if [ 0 -eq 1 ]
    then
    #######################################
    # check if cluster has pending viz jobs and wait if so
	result=1
    #while [ -n $result ]
	while [ $result -ne 0 ]
	do
	    result=`bjobs 2>&1 | grep $jobprefix | grep PEND | wc -w`
	    sleep 2
	    echo "."
	done
    fi



    ################
    # setup arguments to pass to bsub
    start=$i
    finish=$i
    animskip=1 # usually 1

    echo "start:$start finish:$finish animskip:$animskip"

    mkdir -p ~/orangejobs/
    outputfile=~/orangejobs/output.$jobname
    errorfile=~/orangejobs/error.$jobname
    # remove any existing error or output files (careful with -rf!!!)
    rm -rf $outputfile $errorfile


    if [ $remotexserver -eq 1 ]
	then
        #
        # Note in startlotsofxvfb.sh on remote machine that started "5" servers
        # So distribute among those 5 = $numxservers assuming doing 1 in turn
        #
        # but lowest display number is $startxnum
        #
	displaynum=$(($start % $numxservers + $startxnum ))
    fi
    if [ $remotexserver -eq 0 ]
	then
        #
        # Here using local server, so just use $startxnum
        # But system can have multiple cores and can't determine a priori when a core will be used and finished with to end Xvfb, so create own instance assuming only 1 process/core -- handled inside runsmone.sh
        #
	displaynum=$(( $startxnum + 0 ))
    fi


    # bsub note: Only with -x added to bsub would use ptile=1 exclusively

    echo "command: ./runsmone.sh $jobname $mydir $start $finish $animskip $remotexserver $displaynum $numcores $do3dwall $setresnx $setresny"

    # old way with 1 core per bsub call
    #bsub -n 1 -R span[ptile=1] -q kipac-ibq -J $jobname -o $outputfile -e $errorfile -a openmpi ./runsmone.sh $jobname $mydir $start $finish $animskip $remotexserver $displaynum $numcores $do3dwall $setresnx $setresny

    # new way with $numcores per bsub call
    bsub -n $numcores -R span[ptile=$numcores] -q kipac-ibq -J $jobname -o $outputfile -e $errorfile -a openmpi ./runsmmany.sh $jobname $mydir $start $finish $animskip $remotexserver $displaynum $numcores $do3dwall $setresnx $setresny
    
    # store new submission time
    secarray[$i]=$mysec

    




  # done: for i in `cat truelist.txt`
  done

  ####################
  # sleep alot between checks of total completion
  echo "Between total completions"
  sleep 1


  totalresult=`sh checkmissingimage.sh $do3dwall $DOFIELDTYPE $truestart $truefinish $v5dppmrefinedir $v5ddir 2>&1 | wc -w`

  if [ $totalresult -gt 0 ]
      then
      timetofix=1
      trialcount=$(($trialcount+1))
      echo "trialcount: $trialcount  totalresult=$totalresult"
  else
      # then done
      break
  fi


  if [ $trialcount -gt $MAXTRIALS ]
      then
      echo "Too many trials"
      break
  fi




done


 

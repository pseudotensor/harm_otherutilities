#!/bin/bash


# check if any missing images
jobprefix=$1
do3dwall=$2
dofieldtype=$3
truestart=$4
truefinish=$5
v5dppmrefinedir=$6
v5ddir=$7

# remove old fix list
rm -rf listfix$jobprefix.txt

# get list
if [ $dofieldtype -eq 1 ]
then
    ls $v5dppmrefinedir/ifieldline[0-9][0-9][0-9][0-9].ppm > tmp.lis
fi

if [ $dofieldtype -eq 2 ]
then
    ls $v5ddir/ifield*.v5d > tmp.lis
fi

if [ $dofieldtype -eq 0 ]
then
    ls $v5dppmrefinedir/iim0p0s0l*.ppm > tmp.lis
fi

# could also check for:
#grep "broken" error*
#
for i in `seq $truestart $truefinish` ; do
    #
    mynum=$(printf "%04d" $i)
    if [ $dofieldtype -eq 1 ]
    then
	if [ $do3dwall -eq 0 ]
	then
	    myfile=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	fi
	if [ $do3dwall -eq 1 ]
	then
	    # now montage is done during each core job
	    #myfile1=$(printf "%s/ifieldline%s.ppm.left.ppm" $v5dppmrefinedir $mynum)
	    #myfile2=$(printf "%s/ifieldline%s.ppm.right.ppm" $v5dppmrefinedir $mynum)
	    myfile1=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	    myfile2=$(printf "%s/ifieldline%s.ppm" $v5dppmrefinedir $mynum)
	fi
    fi
    
    if [ $dofieldtype -eq 2 ]
    then
	myfile=$(printf "%s/ifieldline%s.v5d" $v5ddir $mynum)
    fi
    
    if [ $dofieldtype -eq 0 ]
    then
	if [ $do3dwall -eq 0 ]
	then
	    myfile=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	fi
	if [ $do3dwall -eq 1 ]
	then
	    #myfile1=$(printf "%s/iim0p0s0l%s.ppm.left.ppm" $v5dppmrefinedir $mynum)
	    #myfile2=$(printf "%s/iim0p0s0l%s.ppm.right.ppm" $v5dppmrefinedir $mynum)
	    myfile1=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	    myfile2=$(printf "%s/iim0p0s0l%s.ppm" $v5dppmrefinedir $mynum)
	fi
    fi
    
    #echo $mynum $myfile

    # check existence of file(s):
    if [ $do3dwall -eq 0 ]
	then
	if [ -s $myfile ]
        then
	    #echo ""
	    touch .
	else
	    echo "No such file $myfile"
	    echo $i >> listfix$jobprefix.txt
	fi
    else
	if [ -s $myfile1 ] &&
	    [ -s $myfile2 ]
	then
	    #echo ""
	    touch .
	else
	    echo "No such file $myfile"
	    echo $i >> listfix$jobprefix.txt
	fi
    fi



done

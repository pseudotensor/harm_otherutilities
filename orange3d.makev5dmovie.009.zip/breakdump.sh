#!/bin/bash
#
echo $1 $2
#
tail -n +2 $2 > $2.$1.temp
head -1 $2 > $2.$1.head.temp
#
awk '{print $7}' $2.$1.temp > $3.temp
cat $2.$1.head.temp $3.temp > $3
rm -rf $3.temp
#
awk '{print $8}' $2.$1.temp > $4.temp
cat $2.$1.head.temp $4.temp > $4
rm -rf $4.temp
#
awk '{print $9}' $2.$1.temp > $5.temp
cat $2.$1.head.temp $5.temp > $5
rm -rf $5.temp
#

# remove temp header
rm -rf $2.$1.head.temp $2.$1.temp

#!/bin/bash
# For 3D wall, see jmckinne@ki-viz03
#/data/kaehler/demos-vizlab/stereo-projection

DATA_DIR=/data/orig/home/mturk/stereo/
STEREO_MOVIE_DIR=~/vis5d

# run movie as:
$DATA_DIR/mplayer -vo gl2_stereo -x 1920 -y 1280 -zoom -fs -loop 0 -speed 0.3 -vf pp=lb $STEREO_MOVIE_DIR/gadget_darkMatter.mpg


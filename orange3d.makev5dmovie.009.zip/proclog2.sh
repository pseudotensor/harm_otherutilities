grep "whichpl" 0_logfull.grmhd.out > images.txt
#sed 'N; s/\n[       ]*\([^|]\)/\1/g' images.txt > imagestemp.txt
#perl -e 'while (<>) { if (! /\|$/ ) { chomp; } print ;}' images.txt > imagestemp.txt

perl -p -e 's/\n/ DEATH/g' images.txt | perl -p -e 's/DEATH whichpl/whichpl/g' | perl -p -e 's/DEATH/\n/g'  > images2.txt

sed 's/whichpl: \([0-9]*\) scale: \([0-9]*\) limits: \([0-9]*\) : min,max,avg: \([0-9]*\)/\1 \2 \3 \4/g' images2.txt > images22.txt

sed 's/begin dumping image# \([0-9]*\) whichpl: \([0-9]*\) scale: \([0-9]*\) limits: \([0-9]*\) vartype: \([0-9]*\)/\1 \2 \3 \4/g' images22.txt > images3.txt

#sed 's/end dumping image# \(.*\) whichpl: \(.*\) scale: \(.*\) limits: \(.*\) vartype: \(.*\)/\1 \2 \3 \4/g' images3.txt > images4.txt

sed 's/end dumping image# \(.*\) whichpl: \(.*\) scale: \(.*\) limits: \(.*\) vartype: \(.*\)//g' images3.txt > images4.txt
perl -p -e 's/\n/DEATH /g' images4.txt | perl -p -e 's/DEATH DEATH/DEATH/g' | perl -p -e 's/DEATH/\n/g'  > images5.txt

#perl -p -e -e 'print unless /^$/' images5.txt >  imagesfinal.txt


#perl -p -e 'print if /\S/' images5.txt > imagesfinal.txt


perl -p -e 's/ $//g' images5.txt > imagesfinal.txt

#!bin/bash

# make final full 3dwall movie
#

#GODMARK: Might want to always delete what's in montdir first

mybasedir="/lustre/ki/orange/jmckinne/lustre_grmhd32328/"

do3dwall=1 # 0 or 1 depending upon what ran with runsmall.sh
dofieldtype=1 # usually 1

# range of simulated frames
truestart=0
truefinish=1499
#truefinish=1

# whether to do montage here (no longer required since done for each core)
# so usually 0
dosimmontage=0

# resolution:
if [ $do3dwall -eq 1 ]
then
    nx=1920
    ny=1280
    finalfilename=3dmoviefull
else
    nx=1024
    ny=768
    finalfilename=presentation
fi

# number of frames per intro sequence (2 sequences so far)
# index of array must agree with movieintro loop below
numintroframes[1]=120
numintroframes[2]=300
# number of frames for simulation at t=0 to show beyond normal simulation frames
numsimframe0intro=120

# starting frame number for final full movie
startframe=1
framenumber=$startframe

outdir="./montdir/"
introdir="./introframes/"
simframedir="./v5dppmrefine/"

# go to base directory
cd $mybasedir
mkdir $outdir

#############################
# make fake intro movie

for movieintro in `seq 1 2`
do

    if [ $movieintro -eq 1 ]
    then
	introfile=introframe_intro
    else
	introfile=simframe_intro
    fi

    # duplicate intro frame
    convert $introdir/$introfile.png -resize ${nx}x${ny}! -colorspace RGB -colors 256 -depth 8 $introdir/$introfile.ppm

    if [ $do3dwall -eq 1 ]
    then
        # added 0000 so can use montageleftright.sh
	fakei=0
	fakenum=$(printf "%04d" $fakei)
	
	ln -sf $introfile.ppm  $introdir/$introfile$fakenum.ppm.left.ppm
	ln -sf $introfile.ppm  $introdir/$introfile$fakenum.ppm.right.ppm

        # montage left-right frames
	start=$fakei
	finish=$fakei
	sh montageleftright.sh $start $finish $introfile $introdir $outdir $nx $ny

    else
	# then no montage
	ln -sf $introdir/$introfile.ppm  $outdir/$introfile$fakenum.ppm
    fi


    # assume 30fps, last for 7 seconds = 210 frames
    start=$framenumber
    finish=$(($framenumber + ${numintroframes[$movieintro]}-1))

    for i in `seq $start $finish`
    do
	mynum=$(printf "%04d" $i)

	infile=$(printf "%s%s%s.ppm" "../introframes/" $introfile $fakenum)
	outfile=$(printf "%s%s%s.ppm" $outdir $finalfilename $mynum)
	echo "Link: $infile -> $outfile"
	ln -sf $infile $outfile
	
	framenumber=$(($framenumber+1))
    done

done

# DEBUG:
#exit 0

########
# montage actual simulation frames

cd $mybasedir

simbasename=ifieldline
start=$framenumber
finish=$(($framenumber + $numsimframe0intro + ($truefinish-$truestart)))

# start of simulation frame
simframe=$truestart

# link to correct file name
for i in `seq $start $finish`
do
    mynum=$(printf "%04d" $i)
    simnum=$(printf "%04d" $simframe)

    if [ $dosimmontage -eq 1 ]
    then
        # put links in v5dppmrefine
	myfile=$(printf "%s%s%s.ppm.left.ppm" $simframedir $finalfilename $mynum)
	simfile=$(printf "%s%s.ppm.left.ppm" $simbasename $simnum)
	ln -sf $simfile $myfile
    
	myfile=$(printf "%s3%s%s.ppm.right.ppm" $simframedir $finalfilename $mynum)
	simfile=$(printf "%s%s.ppm.right.ppm" $simbasename $simnum)
	ln -sf $simfile $myfile
    else
	# montage already done, put final link in montdir still
	myfile=$(printf "%s%s%s.ppm" $outdir $finalfilename $mynum)
	simfile=$(printf "%s%s.ppm" ../$simframedir/$simbasename $simnum)
	ln -sf $simfile $myfile	
    fi

    framenumber=$(($framenumber+1))
    if [ $i -ge $(($start + $numsimframe0intro)) ]
	then
	# only iterate simulation frame if beyond first frame by certain amount
	simframe=$(($simframe+1))
    fi
done

if [ $do3dwall -eq 1 ]
then
    if [ $dosimmontage -eq 1 ]
    then
        # make montage of left&right frames to a single frame for 3D wall
	sh montageleftright.sh $start $finish $finalfilename $simframedir $outdir $nx $ny
    fi
fi

# go to mont dir to make mpeg:
cd $outdir

if [ $do3dwall -eq 1 ]
then
    mpeg2encode ../mpeg1.3dwall.fullintro.par 3dwallfull.mpg
else
    mpeg2encode ../mpeg1.presentation.fullintro.par presentation.mpg
fi

# back to base directory
cd ..




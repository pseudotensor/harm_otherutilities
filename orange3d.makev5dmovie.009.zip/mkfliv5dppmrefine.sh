#!/bin/bash
#
nx=$1
ny=$2
# check for existence of arguments
if ([ -z $1 ] || [ -z $2 ]) ; then {
	echo "usage: sh mkfli.sh nx ny"
	exit
} ; fi

ls v5dppmrefine/ifield*.ppm > tmp.lis
#ls v5dppmrefine/iim0p0s0l*.ppm > tmp.lis
ppm2fli -N -g $nx'x'$ny  -s 0 tmp.lis v5dppmrefine.fli
rm tmp.lis

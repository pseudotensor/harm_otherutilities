echo "set outputfilename" \"$1\" > $8
#
echo "set ixmin [expr $2]" >> $8
echo "set ixmax [expr $3]" >> $8
#
echo "set iymin [expr $4]" >> $8
echo "set iymax [expr $5]" >> $8
#
echo "set izmin [expr $6]" >> $8
echo "set izmax [expr $7]" >> $8
#


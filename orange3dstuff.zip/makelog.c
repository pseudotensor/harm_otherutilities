//
// to compile: gcc -lm -o makelog makelog.c
//
// to run: ./makelog 1E-6 < ./dumps/rhotest > ./dumps/logrhotest 
//
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(int argc, char *argv[])
{

  double offset;
  double x,logx;

  if(argc!=2){
    fprintf(stderr,"Need 1 argument\n");
    exit(1);
  }
  else{
    sscanf(argv[1],"%lf",&offset);
    fprintf(stderr,"offset=%g\n",offset);
  }
  

  while(!feof(stdin)){
    fscanf(stdin,"%lf",&x);
    // use fabs in case interpolated version is negative
    logx=log(fabs(x)+offset); // natural log
    fprintf(stdout,"%21.15g\n",logx);
  }
  

  return(0);


}

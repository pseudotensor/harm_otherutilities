#!/bin/bash
#
echo $1
#
tail -n +2 $1 > $1.temp
head -1 $1 > $1.head.temp
#
awk '{print $1}' $1.temp > $2.temp
cat $1.head.temp $2.temp > $2
rm -rf $2.temp
#
awk '{print $2}' $1.temp > $3.temp
cat $1.head.temp $3.temp > $3
rm -rf $3.temp
#
awk '{print $3}' $1.temp > $4.temp
cat $1.head.temp $4.temp > $4
rm -rf $4.temp
#
awk '{print $4}' $1.temp > $5.temp
cat $1.head.temp $5.temp > $5
rm -rf $5.temp
#
awk '{print $5}' $1.temp > $6.temp
cat $1.head.temp $6.temp > $6
rm -rf $6.temp
#
awk '{print $6" "$7" "$8}' $1.temp > $7.temp
cat $1.head.temp $7.temp > $7
rm -rf $7.temp
#
awk '{print $6" "$7" "$8}' $1.temp > $8.temp
cat $1.head.temp $8.temp > $8
rm -rf $8.temp
#
awk '{print $6" "$7" "$8}' $1.temp > $9.temp
cat $1.head.temp $9.temp > $9
rm -rf $9.temp
#
awk '{print $9" "$10" "$11}' $1.temp > ${10}.temp
cat $1.head.temp ${10}.temp > ${10}
rm -rf ${10}.temp
#
awk '{print $9" "$10" "$11}' $1.temp > ${11}.temp
cat $1.head.temp ${11}.temp > ${11}
rm -rf ${11}.temp
#
awk '{print $9" "$10" "$11}' $1.temp > ${12}.temp
cat $1.head.temp ${12}.temp > ${12}
rm -rf ${12}.temp
#

# remove temp header
rm -rf $1.head.temp $1.temp
